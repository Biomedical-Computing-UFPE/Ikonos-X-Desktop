Official page:
http://wiki.lazarus.freepascal.org/Parallel_procedures
